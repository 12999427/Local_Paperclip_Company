---
name: "SQLite Browser — test suite"
assignee: "test-engineer"
---

Scrivi test completi con pytest: upload file validi e invalidi, introspection schema su DB con tipi misti, esecuzione query SELECT/INSERT/UPDATE/DELETE, paginazione risultati, export CSV e JSON, timeout sessione, DB corrotti o locked, query con risultati vuoti, tabelle con 0 colonne. Coverage minimo 80%. Includi fixtures con DB SQLite di test pre-popolati.
