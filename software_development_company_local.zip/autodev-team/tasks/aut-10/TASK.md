---
name: "Security Review — SQLite Web Browser"
assignee: "security-reviewer"
---

Esegui una revisione di sicurezza completa dell'applicazione SQLite Web Browser.

## Scope

- File upload validation (path traversal, file type spoofing)
- SQL injection surface (user-provided SQL queries)
- Session management security
- XSS prevention nel rendering dei risultati
- CORS configuration
- Temporary file cleanup
- Error message information leakage

## File da Revisionare

- `app.py` — Backend Flask con tutti gli endpoint
- `static/app.js` — Frontend JavaScript
- `templates/index.html` — Template HTML

## Deliverable

Report con severity levels (CRITICAL/HIGH/MEDIUM/LOW) e fix raccomandati.
