---
name: "User Documentation — SQLite Web Browser"
assignee: "tech-writer"
---

Scrivi la documentazione utente per il SQLite Web Browser.

## Requisiti

- Guida rapida (Quick Start)
- Descrizione di tutte le funzionalità:
  - Come aprire un database
  - Come navigare tabelle e schema
  - Come scrivere ed eseguire query SQL
  - Come esportare risultati (CSV/JSON)
  - Come creare grafici
  - Scorciatoie tastiera
- Troubleshooting comune
- Screenshots o descrizioni UI

## Deliverable

Aggiornamento del README.md con documentazione utente completa, oppure file docs/ separato.
