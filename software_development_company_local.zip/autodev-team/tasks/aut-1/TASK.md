---
name: "Sviluppa web app di monitoraggio processi di sistema"
assignee: "tech-lead"
---

Crea un'applicazione web cross-platform (Windows, macOS, Linux) che permetta di visualizzare in tempo reale i processi attivi sul dispositivo, simile a un task manager.

## Requisiti tecnici

* Backend Python con Flask
* Lettura processi tramite libreria psutil (cross-platform)
* Frontend web con auto-refresh (ogni 2-3 secondi)
* Tabella processi con: PID, nome, CPU%, memoria%, stato, utente
* Possibilità di ordinare per colonna
* Filtro per nome processo
* Indicatori grafici per CPU e RAM totale del sistema

## Deliverable

* Codice sorgente completo
* requirements.txt
* Istruzioni di avvio
* Funziona su tutti e tre i principali OS senza modifiche

## Note per il Tech Lead

Coordina Architect per la struttura del progetto, Backend Developer per Flask+psutil, Frontend Developer per l'interfaccia, Test Engineer per i test cross-platform, Security Reviewer per eventuali rischi (esposizione dati di sistema), Tech Writer per la documentazione.
