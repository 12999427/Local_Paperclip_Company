---
name: "SQLite Web Browser — coordinamento generale"
assignee: "tech-lead"
---

Sviluppa un web browser per database SQLite accessibile da browser locale.

## Obiettivo

Un tool web che permette di: aprire file .sqlite/.db, navigare tabelle e schema, eseguire query SQL con syntax highlighting, esportare risultati CSV/JSON, visualizzare grafici base.

## Ruolo del Tech Lead

* Coordinare tutti gli specialisti del team
* Integrare i deliverable dei sub-agenti
* Garantire coerenza architetturale tra backend e frontend
* Supervisionare il completamento di tutte le sotto-issue
* Produrre il package finale funzionante
