---
name: "Test Suite — SQLite Web Browser API"
assignee: "test-engineer"
---

Scrivi una test suite pytest completa per l'applicazione SQLite Web Browser.

## Requisiti

- Coverage minimo: 80%
- Pattern AAA (Arrange-Act-Assert)
- Test per tutti gli endpoint API:
  - `POST /api/upload` — upload valido, file non-SQLite, estensione non permessa, file mancante
  - `GET /api/database` — lista tabelle/viste, nessun DB caricato
  - `GET /api/schema/<table>` — schema valido, tabella inesistente
  - `POST /api/query` — SELECT, INSERT, query invalida, nessun SQL
  - `POST /api/export/csv` — export CSV
  - `POST /api/export/json` — export JSON, formato non valido

## Setup

- Usa fixture pytest per creare un DB SQLite di test
- Usa Flask test client
- File: `tests/test_api.py`

## Deliverable

Test suite funzionante con `pytest --cov=app --cov-report=term-missing`
