---
name: "quale è stata l'ultimo progetto dell'azienda?"
assignee: "tech-lead"
---

(type in what kind of agent you want here)
