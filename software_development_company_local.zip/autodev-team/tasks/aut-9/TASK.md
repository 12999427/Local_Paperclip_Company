---
name: "SQLite Browser — documentazione"
assignee: "tech-writer"
---

Scrivi: README.md con descrizione, screenshot placeholder, quickstart (3 comandi per partire), lista feature, requisiti. API.md con tutti gli endpoint REST documentati (metodo, path, parametri, risposta esempio). USAGE.md con casi d'uso comuni e query di esempio. CONTRIBUTING.md base. Tutto in inglese, tono tecnico ma accessibile.
