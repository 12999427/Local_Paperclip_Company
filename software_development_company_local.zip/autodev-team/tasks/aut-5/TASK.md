---
name: "SQLite Browser — frontend web"
assignee: "frontend-developer"
---

Implementa il frontend: editor SQL con syntax highlighting (CodeMirror o Monaco), tabella risultati ordinabile/filtrabile, pannello schema ad albero (tabelle > colonne), tab per query multiple, grafici base sui risultati (Chart.js — bar, line, pie auto-detect su dati numerici), pulsanti export CSV/JSON, indicatore di stato connessione DB. Vanilla JS o Vue leggero, nessun framework pesante.
