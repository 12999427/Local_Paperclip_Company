---
name: "SQLite Browser — backend Flask"
assignee: "backend-developer"
---

Implementa il backend Python/Flask: upload e apertura file .sqlite/.db, endpoint per schema introspection (tabelle, colonne, tipi, indici, foreign keys), endpoint esecuzione query SQL con risultati paginati, endpoint export CSV e JSON, gestione sessioni database in memoria con timeout, gestione errori SQL chiari. Usa sqlite3 stdlib, nessuna dipendenza ORM.
