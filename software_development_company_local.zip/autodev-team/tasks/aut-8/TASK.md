---
name: "SQLite Browser — packaging e devops"
assignee: "devops"
---

Crea: requirements.txt completo con versioni pinned, Dockerfile per esecuzione containerizzata, script di avvio start.sh con check dipendenze, variabili di configurazione via env (porta, max file size, timeout sessione, directory upload), .gitignore, .dockerignore. Verifica che il tool parta con un singolo comando sia in locale che via Docker.
