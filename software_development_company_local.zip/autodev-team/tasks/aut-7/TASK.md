---
name: "SQLite Browser — security review"
assignee: "security-reviewer"
---

Analizza il codice per: SQL injection (anche su query utente esplicite — va limitato o sandboxato?), path traversal nel caricamento file da path locale, dimensione massima file caricabili, esposizione di dati sensibili nel DB nei log, rate limiting sulle query, possibilità di query distruttive (DROP TABLE) — decidere se bloccare o richiedere conferma. Produci report con severità e fix consigliati.
