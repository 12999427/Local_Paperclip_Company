---
name: "SQLite Browser — architettura di sistema"
assignee: "architect"
---

Progetta l'architettura completa: struttura moduli, API REST endpoints, gestione sessioni multi-database (upload file + path locale), formato risposta JSON per schema e query results, scelta libreria frontend per SQL editor e data grid. Produci un documento architettura (ARCHITECTURE.md) con diagramma componenti e contratti API prima che backend e frontend inizino.
