---
name: "paperclip-dev"
description: ">"
slug: "paperclip-dev"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "1b89a8e3b86a68b1eb59c62863991fc50cb15fd1"
      path: "skills/paperclip-dev"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-dev"
key: "paperclipai/paperclip/paperclip-dev"
---

