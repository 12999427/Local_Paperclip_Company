---
name: "para-memory-files"
description: ">"
slug: "para-memory-files"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "1b89a8e3b86a68b1eb59c62863991fc50cb15fd1"
      path: "skills/para-memory-files"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/para-memory-files"
key: "paperclipai/paperclip/para-memory-files"
---

