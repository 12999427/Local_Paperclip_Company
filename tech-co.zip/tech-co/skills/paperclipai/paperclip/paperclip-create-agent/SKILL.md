---
name: "paperclip-create-agent"
description: ">"
slug: "paperclip-create-agent"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "1b89a8e3b86a68b1eb59c62863991fc50cb15fd1"
      path: "skills/paperclip-create-agent"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-create-agent"
key: "paperclipai/paperclip/paperclip-create-agent"
---

