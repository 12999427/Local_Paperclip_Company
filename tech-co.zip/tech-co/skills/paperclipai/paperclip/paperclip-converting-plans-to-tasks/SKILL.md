---
name: "paperclip-converting-plans-to-tasks"
description: ">"
slug: "paperclip-converting-plans-to-tasks"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "1b89a8e3b86a68b1eb59c62863991fc50cb15fd1"
      path: "skills/paperclip-converting-plans-to-tasks"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-converting-plans-to-tasks"
key: "paperclipai/paperclip/paperclip-converting-plans-to-tasks"
---

