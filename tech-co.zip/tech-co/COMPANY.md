---
name: "Tech Co"
schema: "agentcompanies/v1"
slug: "tech-co"
---

