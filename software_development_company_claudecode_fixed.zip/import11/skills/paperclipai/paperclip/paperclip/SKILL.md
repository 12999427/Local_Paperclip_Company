---
name: "paperclip"
description: ">"
slug: "paperclip"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "69a368ed5183b10eacbc944480ec00b23f528b1e"
      path: "skills/paperclip"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/paperclip"
key: "paperclipai/paperclip/paperclip"
---

