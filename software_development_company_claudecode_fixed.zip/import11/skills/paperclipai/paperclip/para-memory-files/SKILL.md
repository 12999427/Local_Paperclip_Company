---
name: "para-memory-files"
description: ">"
slug: "para-memory-files"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "69a368ed5183b10eacbc944480ec00b23f528b1e"
      path: "skills/para-memory-files"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/para-memory-files"
key: "paperclipai/paperclip/para-memory-files"
---

