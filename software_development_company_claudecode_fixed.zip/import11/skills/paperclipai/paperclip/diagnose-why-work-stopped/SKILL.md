---
name: "diagnose-why-work-stopped"
description: ">"
slug: "diagnose-why-work-stopped"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "69a368ed5183b10eacbc944480ec00b23f528b1e"
      path: "skills/diagnose-why-work-stopped"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/diagnose-why-work-stopped"
key: "paperclipai/paperclip/diagnose-why-work-stopped"
---

