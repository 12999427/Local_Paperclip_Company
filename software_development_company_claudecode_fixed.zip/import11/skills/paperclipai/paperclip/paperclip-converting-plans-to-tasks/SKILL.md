---
name: "paperclip-converting-plans-to-tasks"
description: ">"
slug: "paperclip-converting-plans-to-tasks"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "69a368ed5183b10eacbc944480ec00b23f528b1e"
      path: "skills/paperclip-converting-plans-to-tasks"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-converting-plans-to-tasks"
key: "paperclipai/paperclip/paperclip-converting-plans-to-tasks"
---

