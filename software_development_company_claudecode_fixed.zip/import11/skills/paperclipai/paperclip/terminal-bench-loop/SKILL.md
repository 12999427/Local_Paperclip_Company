---
name: "terminal-bench-loop"
description: ">"
slug: "terminal-bench-loop"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "69a368ed5183b10eacbc944480ec00b23f528b1e"
      path: "skills/terminal-bench-loop"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/terminal-bench-loop"
key: "paperclipai/paperclip/terminal-bench-loop"
---

