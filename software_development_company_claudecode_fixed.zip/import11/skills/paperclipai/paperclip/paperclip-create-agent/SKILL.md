---
name: "paperclip-create-agent"
description: ">"
slug: "paperclip-create-agent"
metadata:
  sources:
    -
      kind: "github-dir"
      commit: "69a368ed5183b10eacbc944480ec00b23f528b1e"
      path: "skills/paperclip-create-agent"
      repo: "paperclipai/paperclip"
      trackingRef: "master"
      url: "https://github.com/paperclipai/paperclip/tree/master/skills/paperclip-create-agent"
key: "paperclipai/paperclip/paperclip-create-agent"
---

